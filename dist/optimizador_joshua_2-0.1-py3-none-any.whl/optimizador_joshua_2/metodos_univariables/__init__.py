from .biseccion import biseccion
from .fibonacci import fibonacci 
from .golden import goldensearch
from .interval import interval
from .newtonraphson import newton_raphson
from .secante import secante